VETERAN

Windows will say a virus has been detected.
This is because they don't recognise the hacking tool
Allow the hacking tool on this device in settings (Windows security).
Open "HackTool" or "something".
Hack other computers lmao
